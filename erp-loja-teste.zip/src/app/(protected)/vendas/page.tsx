import {redirect} from 'next/navigation';
import {pageActor} from '../../../lib/auth';
import {Sales} from '../../../components/sales';
export default async function SalesPage(){const a=await pageActor();if(a.mustChangePassword)redirect('/conta');if(!a.permissions.includes('sales.create')&&!a.permissions.includes('sales.finalize'))return <section className="card"><h1>Acesso restrito</h1></section>;return <><p className="eyebrow">ATENDIMENTO NO BALCÃO</p><h1>Vendas</h1><p className="muted page-intro">Do carrinho ao pagamento, tudo registrado.</p><Sales create={a.permissions.includes('sales.create')} finalize={a.permissions.includes('sales.finalize')} manage={['ADMIN','MANAGER'].includes(a.roleCode)} cashManage={a.permissions.includes('cash.manage')}/></>;}
